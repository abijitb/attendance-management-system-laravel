<?php

class Student extends Eloquent {

	protected $table = "students";
	protected $primaryKey = 'stdn_id';
}